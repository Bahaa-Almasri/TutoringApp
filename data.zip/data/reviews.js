const reviews = [
    {
        "user": "Elie Sawma Awad",
        "profile": "pic",
        "review": '"Lectus, nonummy et. Occaecat delectus erat, minima dapibus ornare nunc, autem."',
        "rating": 5
    },
    {
        "user": "Bahaa Al Masri",
        "profile": "pic",
        "review": '"Lectus, nonummy et. Occaecat delectus erat, minima dapibus ornare nunc, autem."',
        "rating": 5
    },
    {
        "user": "Matteo Haddad",
        "profile": "pic",
        "review": '"Lectus, nonummy et. Occaecat delectus erat, minima dapibus ornare nunc, autem."',
        "rating": 4
    },
    {
        "user": "Clara Zammar",
        "profile": "pic",
        "review": '"Lectus, nonummy et. Occaecat delectus erat, minima dapibus ornare nunc, autem."',
        "rating": 4
    },
    {
        "user": "Elie Sawma Awad",
        "profile": "pic",
        "review": '"Lectus, nonummy et. Occaecat delectus erat, minima dapibus ornare nunc, autem."',
        "rating": 5
    },
    {
        "user": "Matteo Haddad",
        "profile": "pic",
        "review": '"Lectus, nonummy et. Occaecat delectus erat, minima dapibus ornare nunc, autem."',
        "rating": 2
    },
    {
        "user": "Clara Zammar",
        "profile": "pic",
        "review": '"Lectus, nonummy et. Occaecat delectus erat, minima dapibus ornare nunc, autem."',
        "rating": 4
    }
];

export default reviews;