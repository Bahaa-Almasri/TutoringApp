const majors = [
    {
        "name": "Computer Engineering",
        "abbreviation": "COE",
        "courses": 12
    },
    {
        "name": "Mechatronics Engineering",
        "abbreviation": "MCE",
        "courses": 20
    },
    {
        "name": "Electrical Engineering",
        "abbreviation": "ECE",
        "courses": 1
    },
    {
        "name": "Mechatronics Engineering",
        "abbreviation": "MCE",
        "courses": 20
    },
    {
        "name": "Mechatronics Engineering",
        "abbreviation": "MCE",
        "courses": 20
    },
    {
        "name": "Mechatronics Engineering",
        "abbreviation": "MCE",
        "courses": 20
    },
    {
        "name": "Mechatronics Engineering",
        "abbreviation": "MCE",
        "courses": 20
    },
    {
        "name": "Mechatronics Engineering",
        "abbreviation": "MCE",
        "courses": 20
    },
    {
        "name": "Mechatronics Engineering",
        "abbreviation": "MCE",
        "courses": 20
    },
    {
        "name": "Mechatronics Engineering",
        "abbreviation": "MCE",
        "courses": 20
    },
    {
        "name": "Mechatronics Engineering",
        "abbreviation": "MCE",
        "courses": 20
    }
];

export default majors;
