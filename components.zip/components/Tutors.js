import React from "react";
import "../styles/styles.css";
import PageIntro from "./PageIntro";
import TutorsSearchBar from "./TutorsSearchBar";
import TutorBox from "./TutorBox";
import Footer from "./Footer";
import { useLocation } from "react-router-dom";

export default function Tutors() {
    const location = useLocation();
    const token = location.state ? location.state.token : "";
    const [formData, setFormData] = React.useState({ "course": "", "rating": "all", "language": "", "hourlyRate" : ""});
    
    const [tutors, setTutors] = React.useState([]);
    const [tutorsElements, setTutorsElements] = React.useState([]);
    const [tutorsFiltered, setTutorsFiltered] = React.useState([]);

    // Know when no filter is applied
    function isFiltered() {
        return !(formData.course === "" && formData.language === "" && formData.hourlyRate === "");
    }

    // Extract the id and the name
    const extractId = (value) => {
        return value.substring(0, value.search('-'));
    }

    const extractName = (value) => {
        return value.substring(value.search('-') + 1);
    }

    // Get all tutors and all their courses
    const fetchTutors = async () => {
        try {
            const res = await fetch(`http://127.0.0.1:8000/listTutors`);
            const data = await res.json();
            setTutors(data);
        } catch(error) {
            console.log(error);
        }
    }

    // Get the name of the language
    const fetchLanguage = async (id) => {
        try {
            const res = await fetch(`http://127.0.0.1:8000/language/${id}`);
            const data = await res.json();
            return data;
        } catch(error) {
            console.log(error);
        }
    }


    React.useEffect(() => {
        fetchTutors();
    }, [])
    
    React.useEffect(() => {
        if (tutorsFiltered.length === 0 && !isFiltered()) {
            Promise.all(
                tutors.map((tutor, id) => {
                    // get the languages
                    const languagesPromises = tutor.languages.map((id) => fetchLanguage(id));
    
                    return Promise.all(languagesPromises)
                        .then((languageNames) => {
                            const languagesArr = languageNames.map((lang) => lang.name);
        
                            // generate random rating
                            const randomRating = Math.floor(Math.random() * 40 + 10) / 10;
                            return (
                                <TutorBox
                                    key={id}
                                    id={tutor.id}
                                    tutor={`${tutor.first_name} ${tutor.last_name}`}
                                    course={tutor.course}
                                    languages={languagesArr}
                                    hourlyRate={tutor.rate}
                                    description={tutor.description}
                                    rating={randomRating}
                                    code={tutor.code}
                                    token={token}
                                />
                            );
                        })
                        .catch((error) => {
                            console.error("Error fetching language names: ", error);
                            return null;
                        });
                })
            )
            .then((tutorElements) => {
                // Remove null elements (due to error handling)
                const filteredTutorElements = tutorElements.filter(element => element !== null);
                setTutorsElements(filteredTutorElements);
            })
            .catch((error) => {
                console.error("Error creating TutorBox elements: ", error);
            });
        } else {
            if (tutorsFiltered.length === 0) setTutorsElements([]);
            else {
                Promise.all(
                    tutorsFiltered.map((tutor, id) => {
                        // get the languages
                        const languagesPromises = tutor.languages.map((id) => fetchLanguage(id));
        
                        return Promise.all(languagesPromises)
                            .then((languageNames) => {
                                const languagesArr = languageNames.map((lang) => lang.name);
            
                                // generate random rating
                                const randomRating = Math.floor(Math.random() * 40 + 10) / 10;
                                return (
                                    <TutorBox
                                        key={id}
                                        id={tutor.id}
                                        tutor={`${tutor.first_name} ${tutor.last_name}`}
                                        course={tutor.course}
                                        languages={languagesArr}
                                        hourlyRate={tutor.rate}
                                        description={tutor.description}
                                        rating={randomRating}
                                        code={tutor.code}
                                        token={token}
                                    />
                                );
                            })
                            .catch((error) => {
                                console.error("Error fetching language names: ", error);
                                return null;
                            });
                    })
                )
                .then((tutorElements) => {
                    // Remove null elements (due to error handling)
                    const filteredTutorElements = tutorElements.filter(element => element !== null);
                    setTutorsElements(filteredTutorElements);
                })
                .catch((error) => {
                    console.error("Error creating TutorBox elements: ", error);
                });
            }
        }
        
    }, [formData, tutors, tutorsFiltered]);

    return (
        <div className="flex-column">
            <PageIntro 
                active="tutors"
                title="Tutors"
                description="Browse the available tutors for your specified course."
                background="background-image-tutors"
                token={token}
            />

            <div id="tutors--container">
                <TutorsSearchBar 
                    formData={formData}
                    setFormData={setFormData}
                    tutorsFiltered={tutorsFiltered}
                    setTutorsFiltered={setTutorsFiltered}
                    tutors={tutors}
                    setTutors={setTutors}
                />

                <div id="tutors-available--container">
                    <h1 className="large-bold-title">Available Tutors{formData.course !== "" ? ` for ${extractName(formData.course)}` : ""}</h1>
                    <hr className="small-hr" id="tutors-hr"></hr>
                    {tutorsElements && (tutorsElements.length === 0 || (isFiltered() && tutorsFiltered.length === 0)) ? <p>There is no tutor available.</p> : tutorsElements}
                </div>
            </div>

            <Footer token={token} />
        </div>
    )
}