import React from "react";

export default function SmallIntro(props) {
    const { smallTitle, title, description } = props;

    return (
        <div id="smallintro--container">
            <p className="small-title">{smallTitle}</p>

            <h1>{title}</h1>
            <hr></hr>

            <p className="light-grey">{description}</p>
        </div>
    )
}
