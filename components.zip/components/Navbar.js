import React from "react";
import "../styles/navbar.css";
import "../styles/styles.css";
import { Link } from "react-router-dom";

export default function Navbar(props) {
    return (
        <nav id="navbar--container">
            <div id="navbar--titles">
                <Link 
                    to="/" 
                    className={`navbar--title${props.active === "home" ? " navbar--title-active" : ""}`}
                    state={{ token: props.token }}
                >Home</Link>
                <Link 
                    to="/courses" 
                    className={`navbar--title${props.active === "courses" ? " navbar--title-active" : ""}`} 
                    state={{ token: props.token }}
                >Courses</Link>
                <Link 
                    to="/tutors" 
                    className={`navbar--title${props.active === "tutors" ? " navbar--title-active" : ""}`}
                    state={{ token: props.token }}
                >Tutors</Link>
                <Link 
                    to="/about" 
                    className={`navbar--title${props.active === "about" ? " navbar--title-active" : ""}`}
                    state={{ token: props.token }}
                >About</Link>
                <Link 
                    to="/contact" 
                    className={`navbar--title${props.active === "contact" ? " navbar--title-active" : ""}`}
                    state={{ token: props.token }}    
                >Contact</Link>
                {props.token === "" && <Link 
                    to="/sign-up" 
                    className= "sign-up-navBar"
                    state={{ token: props.token }}    
                >Sign Up</Link>}
            </div>
        </nav>
    )
}