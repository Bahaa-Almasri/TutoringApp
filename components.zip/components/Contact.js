import React from 'react';
import "../styles/contact.css";
import Footer from "../components/Footer.js";
import PageIntro from "../components/PageIntro";
import "../styles/styles.css";
import SmallIntro from './SmallIntro.js';
import { useLocation } from "react-router-dom";

function Contact() {
    const location = useLocation();
    const token = location.state ? location.state.token : "";

    return (
        <div className="flex-column"> 
            <PageIntro 
                active={"contact"} 
                title={"Contact Us"} 
                description={"Connect with us for any inquiry or assistance!"} 
                background={"background-image-contact"}
                token={token}
            />
            
            <div id="contact--container">
                <SmallIntro 
                    smallTitle={"Contact Us"}
                    title={"Media and Business Inquiries"}
                    description={<p>Send us a message below or email us at: <a className="mail" href="mailto:tutortopia@gmail.com">tutortopia@gmail.com</a></p>}
                />

                <div className="form-container">
                    <form>
                        <div className="form-row">
                            <label htmlFor="firstName" className="label">Name <span className="red">*</span></label>
                            <div className="input-group--contact">
                                <input type="text" id="firstName" placeholder="First" required />
                                <input type="text" id="lastName" placeholder="Last" required />
                            </div>
                        </div>
                        <div className="form-row">
                            <label htmlFor="email" className="label">Email <span className="red">*</span></label>
                            <input type="email" id="email" placeholder="Your email" required />
                        </div>
                        <div className="form-row">
                            <label htmlFor="message" className="label">Message <span className="red">*</span></label>
                            <textarea id="message" placeholder="Your message" required></textarea>
                        </div>
                        <div className="form-row">
                            <button type="submit" className="submit-button">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
            <Footer token={token} />
         </div>
    );
}

export default Contact;
