import React from 'react';
import '../styles/signUpPage.css';
import { Link } from "react-router-dom";
import axios from "axios";

export default function SignUpPage() {
    const [message, setMessage] = React.useState("");
    const [showMessage, setShowMessage] = React.useState(false);

    const [languages, setLanguages] = React.useState([]);
    const [languagesOptions, setLanguageOptions] = React.useState([]);
    const [courses, setCourses] = React.useState([]);
    const [coursesOptions, setCoursesOptions] = React.useState([]);

    const [formData, setFormData] = React.useState({
        first_name: "",
        last_name: "",
        email: "",
        password: "",
        is_tutor: false,
        languages: [],
        username: ""
    });

    // Changes when we show the succesful add to the database
    const showStatus = (msg) => {
        setMessage(msg);
        setShowMessage(true);

        setTimeout(() => setShowMessage(false), 3900);
    }

    function handleChange(event) {
        if (!formData.is_tutor) {
            setFormData((prev) => {
                return {
                    ...prev,
                    description: "",
                    rate: ""
                }
            })
        }

        if (event.target.name === "is_tutor") {
            setFormData((prev) => {
                return {
                    ...prev,
                    [event.target.name]: event.target.value === "tutor"
                }
            })
        } else {
            setFormData((prev) => {
                return {
                    ...prev,
                    [event.target.name]: event.target.value 
                }
            })
        }
    }

    // To deal with the language
    function handleCheckbox(event) {
        const currCourse = event.target.value;

            if (!event.target.checked) {
                setFormData((prev) => {
                    const currArr = prev.languages.filter(course => Number(course) !== Number(currCourse));
                    return {
                        ...prev,
                        "languages": currArr
                    }
                });
            } else {
                setFormData((prev) => {
                    const currArr = [...prev.languages];
                    currArr.push(Number(currCourse));
                    return {
                        ...prev,
                        "languages": currArr
                    };
                })
            }
    }
    
    // To deal with the select
    function handleSelect(event) {
        const { name, options } = event.target;
        const selectedValues = Array.from(options)
                                .filter(option => option.selected)
                                .map(option => Number(option.value));
        
        setFormData(prev => {
            return {
                ...prev,
                "taughtCourses": selectedValues
            }
        })
    }

    // Get all languages
    const fetchLanguages = async () => {
        try {
            const res = await fetch('http://127.0.0.1:8000/listLanguages');
            const data = await res.json();
            setLanguages(data);
        } catch (error) {
            console.log(error);
        }
    }

    // Get all courses
    const fetchCourses = async () => {
        try {
            const res = await fetch('http://127.0.0.1:8000/courses');
            const data = await res.json();
            setCourses(data);
        } catch (error) {
            console.log(error);
        }
    }

    React.useEffect(() => {
        fetchLanguages();
        fetchCourses();
    }, [])


    // Set up the language options
    React.useEffect(() => {
        setLanguageOptions(() => {
            return languages.map((lang) => {
                return <div>
                            <input type="checkbox" id={lang.name} value={lang.id} onChange={handleCheckbox} />
                            <label htmlFor={lang.name}>{lang.name}</label>
                        </div>;
            })
        })
    }, [languages])

    // Set up the courses options
    React.useEffect(() => {
        setCoursesOptions(() => {
            return courses.map((course) => <option value={course.id}>{course.name}</option>) 
        })
    }, [courses])

    // Submit the form
    async function handleSubmit(event) {
        try {
            await axios.post('http://127.0.0.1:8000/signup', formData);
            showStatus("Account successfully created!");
            setFormData(() => {
                return {
                    first_name: "",
                    last_name: "",
                    email: "",
                    password: "",
                    is_tutor: false,
                    languages: [],
                    username: ""
                }
            })
        } catch (error) {
            console.log(error);
        }
    }

    return (
        <div id="sign-up--container">
            {showMessage &&
                <p id="form-message">{message}</p>
            }
            <Link to="/" className="back-button">
                <span class="material-symbols-outlined">arrow_back_ios</span>
            </Link>
            <div className="contact-section sign-up">
                <div className="contact-header">
                    <h2>Sign Up</h2>
                </div>
                <div className="contact-info">
                    <p>Please fill in the form below to sign up as a student or tutor.</p>
                </div>
                <div className="form-container">
                    <div id="name-sign-up--container">
                        <div className="form-row sign-up--text">
                            <label htmlFor="first" className="label">First Name:</label>
                            <input type="text" name="first_name" placeholder="Enter your first name" className="sign-up--elements" onChange={handleChange} value={formData.first_name} />
                        </div>
                        <div className="form-row sign-up--text">
                            <label htmlFor="last" className="label">Last Name:</label>
                            <input type="text" name="last_name" placeholder="Enter your last name" className="sign-up--elements" onChange={handleChange} value={formData.last_name} />
                        </div>
                    </div>
                    <div className="form-row">
                        <label htmlFor="username" className="label">Username:</label>
                        <input type="text" id="username" name="username" placeholder="Enter your username" className="sign-up--elements" onChange={handleChange} value={formData.username} />
                    </div>
                    <div className="form-row">
                        <label htmlFor="email" className="label">Email:</label>
                        <input type="email" id="email" name="email" placeholder="Enter your email" className="sign-up--elements" onChange={handleChange} value={formData.email} />
                    </div>
                    <div className="form-row">
                        <label htmlFor="password" className="label">Password:</label>
                        <input type="password" id="password" name="password" placeholder="Enter your password" className="sign-up--elements" onChange={handleChange} value={formData.password} />
                    </div>
                    <div className="form-row">
                        <label htmlFor="role" className="label">Sign up as:</label>
                        <select id="role" name="is_tutor" className="sign-up--elements" onChange={handleChange} value={formData.is_tutor ? "tutor" : "student"} >
                            <option value="student">Student</option>
                            <option value="tutor">Tutor</option>
                        </select>
                    </div>
                    {formData.is_tutor &&
                        <div>
                            <div className="form-row">
                                <label htmlFor="description" className="label">Give us a brief description about yourself:</label>
                                <input type="text" id="description" name="description" placeholder="Enter a description" className="sign-up--elements" onChange={handleChange} value={formData.description} />
                            </div>

                            <div className="form-row">
                                <label htmlFor="rate" className="label">Hourly rate:</label>
                                <input type="number" id="rate" name="rate" placeholder="Enter your hourly rate" className="sign-up--elements" onChange={handleChange} value={formData.rate} />
                            </div>

                            <div>
                                <label className="label">Languages:</label>
                                <div id="languages-options--signup">
                                    {languagesOptions}
                                </div>
                            </div>

                            <label htmlFor="taughtCourses" className="label">Courses:</label>
                            <select id="taughtCourses" name="taughtCourses" multiple onChange={handleSelect} className="courses--signup" value={formData.tuaghtCourses}>
                                {coursesOptions}
                            </select>
                        </div>
                    }

                    <div className="form-row">
                        <button type="submit" className="submit-button" onClick={handleSubmit}>Sign Up</button>
                    </div>
                    <div id="sign-in-up-switch">
                        <p>Have an account?</p>
                        <Link to="/sign-in">Sign in.</Link>
                    </div>
                </div>
            </div>
        </div>
    );
};
