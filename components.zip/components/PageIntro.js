import React from "react";
import "../styles/styles.css";
import Navbar from "./Navbar";

export default function PageIntro(props) {
    return (
        <div id="page-intro--container">
            <Navbar active={props.active} token={props.token} />
            <div id="page-intro" className={props.background}>
                <h1>{props.title}</h1>
                <h6>{props.description}</h6>
            </div>
        </div>
    )
}