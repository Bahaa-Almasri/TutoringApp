import React from 'react';
import "../styles/footer.css"; 
import majorsList from "../data/majors";
import { Link } from "react-router-dom";
import SignUpBox from './SignUpBox';

export default function Footer(props) {
    const [majors, setMajors] = React.useState([]);
    const [isSignedIn, setIsSignedIn] = React.useState(props.token !== "");

    React.useEffect(() => {
        setIsSignedIn(props.token && props.token !== "");
    }, [props])

    React.useEffect(() => {
        setMajors(() => {
            return majorsList.slice(0,5).map((major, id) => {
                return <Link to="/courses" state={{ major: major.name }} key={id}>{major.name}</Link>
            })
        })
    }, [majorsList])

    return (
        <div id="footer--container">
            {!isSignedIn && <SignUpBox />}

            <footer className={`footer d-flex justify-content-center flex-wrap${isSignedIn ? " collapse-footer" : ""}`}>
                        <div className={`row footer--sections${isSignedIn ? " collapse-footer-sections" : ""}`}>
                            <div className="col-lg-2 col-md-3 col-sm-6 footer-section">
                                <div className={`footer-section`}>
                                    <h4>About Us</h4>
                                    <ul>
                                        <li><a href="#">How it Works</a></li>
                                        <li><a href="#">Become a Teacher</a></li>
                                        <li><a href="#">FAQs</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div className="col-lg-2 col-md-3 col-sm-6 footer-section">
                                <div className={`footer-section`}>
                                    <h4>Majors</h4>
                                    <div>
                                        {majors}
                                    </div>
                                </div>
                            </div>
                            <div className="col-lg-2 col-md-3 col-sm-6 footer-section">
                                <div className="footer-section">
                                    <h4>Support</h4>
                                    <ul>
                                        <li><a href="#">Need Help? {<br></br>} contact@info.com</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div className="col-lg-2 col-md-3 col-sm-6 footer-section">
                                <div className="footer-section">
                                    <h4>Follow Us</h4>
                                    <ul className="social">
                                        <li><a href="#"><i className="icon fab fa-facebook"></i> Facebook</a></li>
                                        <li><a href="#"><i className="icon fab fa-twitter"></i> Twitter</a></li>
                                        <li><a href="#"><i className="icon fab fa-instagram"></i> Instagram</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div className="col-lg-2 col-md-3 col-sm-6 footer-section">
                                <div className="footer-section">
                                    <h4>Contact Us</h4>
                                    <ul>
                                        <li><a href="#">Phone number</a></li>
                                        <li><a href="#">Lebanese American University - Jbeil </a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                </footer>
        </div>
    );
}
