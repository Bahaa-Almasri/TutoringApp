import React from "react";
import "../styles/styles.css";
import PageIntro from "./PageIntro";
import CoursesSearchBar from "./CoursesSearchBar";
import Box from "./Box";
import Footer from "./Footer";
import { useLocation, Link } from "react-router-dom";

// FIX: THE NUMBER OF TUTORS FOR EACH COURSE

export default function Courses() {
    const { state } = useLocation();

    const currMajor = state ? (state.major ? state.major.name : "") : "";
    const currId = state ? (state.major ? state.major.id : -1) : -1;

    const [courses, setCourses] = React.useState([]);
    const [searchCourse, setSearchCourse] = React.useState("");
    const [coursesElement, setCoursesElement] = React.useState([]);
    const [major, setMajor] = React.useState(currMajor);
    const [majorId, setMajorId] = React.useState(currId);
    const [coursesFiltered, setCoursesFiltered] = React.useState([]);

    // Get the courses for major from the database
    const fetchCourses = async () => {
        try {
            let res;
            if (majorId === -1) {
                // there is no filtering applied
                res = await fetch('http://127.0.0.1:8000/courses');
            } else {
                res = await fetch(`http://127.0.0.1:8000/getMajorCourses/${majorId}`);
            }
            const data = await res.json();
            setCourses(data);
        } catch (error) {
            console.log(error);
        }
    }

    React.useEffect(() => {
        fetchCourses();
    }, [major, majorId])

    React.useEffect(() => {
        setCoursesElement(() => {
            // YOU'LL NEED TO EDIT THE NUMBER OF TUTORS
            if (coursesFiltered.length === 0 && searchCourse === "") {
                return courses.map((course, id) => {
                    return <Link to="/tutors" state={{ course: course, token: state.token }} key={id}>
                                <Box 
                                    key={id}
                                    name={course.name}
                                    abbreviation={course.code}
                                    elementName={`Tutor${3 !== 1 ? "s" : ""}`}
                                    elements={3}
                                    extraClass=" box-courses"
                                />
                            </Link>
                })
            } else {
                return coursesFiltered.map((course, id) => {
                    return <Link to="/tutors" state={{ course: course, state: state.token }} key={id}>
                                <Box 
                                    key={id}
                                    name={course.name}
                                    abbreviation={course.code}
                                    elementName={`Tutor${3 !== 1 ? "s" : ""}`}
                                    elements={3}
                                    extraClass=" box-courses"
                                />
                            </Link>
                })
            }
            
        })
    }, [courses, coursesFiltered])

    return (
        <div className="flex-column">
            <PageIntro 
                active="courses"
                title="Courses"
                description="Explore the available courses with our tutors."
                background="background-image-courses"
                token={state.token}
            />
            
            <div id="courses--container">
                <CoursesSearchBar 
                    major={major}
                    majorId={majorId}
                    courses={courses}
                    coursesFiltered={coursesFiltered}
                    searchCourse={searchCourse}
                    setSearchCourse={setSearchCourse}
                    setCoursesFiltered={setCoursesFiltered}
                    setCourses={setCourses}
                    setMajorId={setMajorId}
                    setMajor={setMajor}
                />
                <div id="courses-available--container">
                    {coursesElement}
                </div>

                {coursesElement.length === 0 ? <p>There is no course available for this major yet.</p> : ""}
            </div>

            <Footer token={state.token} />
        </div>
    )
}