import React from 'react';
import '../styles/signUpPage.css';
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";

export default function SignInPage() {
    const [success, setSuccess] = React.useState(false);
    const navigate = useNavigate();

    const handleRedirect = () => {
        navigate('/', { state: { token: token } });
    };

    const [formData, setFormData] = React.useState({
        username: "",
        password: ""
    })
    const [token, setToken] = React.useState("");

    function handleChange(event) {
        setFormData((prev) => {
            return {
                ...prev,
                [event.target.name]: event.target.value
            }
        })
    }

    async function handleSubmit() {
        try {
            const data = await axios.post('http://127.0.0.1:8000/login', formData);
            setToken(() => data.data.token);
        } catch (error) {
            console.log(error);
        }
    }

    React.useEffect(() => {
        if (success) handleRedirect();
    }, [success])

    React.useEffect(() => {
        if (token !== "") setSuccess(true)
    }, [token])

    return (
        <div id="sign-up--container">
            <Link to="/" className="back-button" state={{ token: `${token}`}}>
                <span class="material-symbols-outlined">arrow_back_ios</span>
            </Link>
            <div className="contact-section">
                <div className="contact-header">
                    <h2>Sign In</h2>
                </div>
                {/* <div className="contact-info">
                    <p>Please fill in the form below to sign up as a student or tutor.</p>
                </div> */}
                <div className="form-container">
                    <div className="form-row">
                        <label htmlFor="username" className="label">Username:</label>
                        <input type="username" id="username" name="username" placeholder="Enter your username" className="sign-up--elements" onChange={handleChange} />
                    </div>
                    <div className="form-row">
                        <label htmlFor="password" className="label">Password:</label>
                        <input type="password" id="password" name="password" placeholder="Enter your password" className="sign-up--elements" onChange={handleChange} />
                    </div>
                    
                    <div className="form-row">
                        <button type="submit" className="submit-button" onClick={handleSubmit}>Sign In</button>
                    </div>
                    <div id="sign-in-up-switch">
                        <p>Don't have an account?</p>
                        <Link to="/sign-up">Sign up.</Link>
                    </div>
                </div>
            </div>
        </div>
    );
};
