import React from "react";
import "../styles/styles.css";
import { Link } from "react-router-dom";

export default function SignUpBox() {
    return (
        <div id="sign-up-box--container">
            <p>Choose a tutor for 1-on-1 lessons</p>
            <h1>
                <span>Start your tutoring journey &nbsp;</span>
                <span className="bold-underlined">today!</span>
            </h1>
            <Link className="small-button" to="/sign-up">Sign Up</Link>
        </div>
    )
}