import React from "react";
import "../styles/styles.css";

export default function Box(props) {
    const { name, abbreviation, elementName, elements, extraClass } = props;

    return (
        <div className={`small-box${extraClass}`}>
            <p className="green-p-box">{abbreviation}</p>
            <div className="element-info">
                <h2 className="light-title">{name}</h2>
                <p className="light-grey">{`${elements} ${elementName}`}</p>
            </div>
        </div>
    )
}