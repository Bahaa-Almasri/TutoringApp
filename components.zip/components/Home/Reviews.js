import React from "react";
import "../../styles/styles.css";
import "../../styles/home.css";
import reviews from "../../data/reviews";

export default function Reviews() {
    const [reviewsElements, setReviewsElements] = React.useState([]);
    
    React.useEffect(() => {
        // Filter them by the highest ratings first and slice it to 5 reviews
        // For this, I will need to sort the reviews
        reviews.sort((a, b) => b.rating - a.rating);
        setReviewsElements([<h1 id="review-title" key={0}>Some Reviews!</h1>, 
                                    ...reviews.slice(0,5)
                                        .map(((review, id) => {
                                            return (
                                                <div className="review-box" key={id+1}>
                                                    <p className="review-box--rating">{review.rating}/5</p>
                                                    <p className="review-box--review">{review.review}</p>
                                                    <span className="material-symbols-outlined review-box--img">account_circle</span>
                                                    <p className="review-box--user">{review.user}</p>
                                                </div>
                                            )
                                        }))
                            ]);
    }, [])


    return (
        <div id="reviews--container">
            {reviewsElements}
        </div>
    )
}