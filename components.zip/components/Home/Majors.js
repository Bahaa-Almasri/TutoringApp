import React from "react";
import Box from "../Box";
import { Link } from "react-router-dom";

export default function Majors(props) {
    const show = ["Show All", "+"];
    const hide = ["Show Less", "-"];

    const [majorsElement, setMajorsElement] = React.useState([]);
    const [showAllButton, setShowAllButton] = React.useState(show)
    const [showAll, setShowAll] = React.useState();
    const [majors, setMajors] = React.useState([]);
     
    // Get the majors from the database
    const fetchMajors = async () => {
        try {
            const res = await fetch('http://127.0.0.1:8000/majors');
            const data = await res.json();
            setMajors(data);
        } catch (error) {
            console.log(error);
        }
    }

    React.useEffect(() => {
        fetchMajors();
        setShowAll(false);
    }, [])

    React.useEffect(() => {
        let majorsArr;

        if (!showAll) {
            majorsArr = [...majors.slice(0,8)];
            setShowAllButton(show);
        } else {
            majorsArr = [...majors]
            setShowAllButton(hide);
        }

        setMajorsElement(majorsArr.map((major, id) => {
            return <Link to="/courses" state={{ major: major, majorId: major.id, token: props.token }} key={id}>
                        <Box 
                            name={major.name}
                            abbreviation={major.code}
                            elementName={`Course${major.num_courses !== 1 ? "s" : ""}`}
                            elements={major.num_courses}
                            extraClass=""
                        />
                    </Link>
        }));
    }, [showAll, majors]);

    function handleClick(event) {
        event.preventDefault();
        setShowAll(prev => !prev);
    }
    

    return (
        <div id="majors--container">
            <div id="majors-elements">
                {majorsElement}
            </div>
            <button className="small-button" onClick={handleClick}>
                <p>{showAllButton[0]}</p>
                <p id="show-all-p">{showAllButton[1]}</p>
            </button>
        </div>
    )
}