import React from "react";
import "../../styles/home.css";

export default function HomeIntro() {
    return (
        <div id="homeintro--container" className="flex-column">
            <div id="homeintro-text">
                <p>In look for a tutor?</p>
                <h1>
                    <span>Start&nbsp;</span>
                    <span className="bold-underlined">learning</span>
                    <span>&nbsp;and<br></br> start your academic comeback&nbsp;</span>
                    <span className="bold-underlined"><br></br>with the best</span>
                    <span>&nbsp;tutors!</span>
                </h1>
            </div>
        </div>
    )
}