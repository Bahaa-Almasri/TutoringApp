import React from "react";
import Navbar from "../Navbar";
import HomeIntro from "./HomeIntro";
import Majors from "./Majors";
import HowItWorks from "./HowItWorks";
import Benefits from "./Benefits";
import Reviews from "./Reviews";
import Footer from "../Footer";
import { useLocation } from "react-router-dom";

export default function Home() {
    const location = useLocation();
    const [token, setToken] = React.useState("");

    React.useEffect(() => {
        setToken(location ? (location.state ? location.state.token : "") : "");
    }, [location]);

    return (
        <div className="flex-column">
            <Navbar active="home" token={token} />
            <HomeIntro />
            <div id="home--container" className="page-container">
                <Majors token={token} />
                <HowItWorks />
                <Benefits />
                <Reviews />
            </div>
            <Footer token={token} />
        </div>
    )
}