import React from "react";
import "../../styles/styles.css";
import "../../styles/home.css";

export default function Benefits() {
    return (
        <div id="benefits--container">
            <hr></hr>

            <div id="benefits--sections">
                <div className="benefits--section">
                    <span className="material-symbols-outlined home-icon">school</span>
                    <h3>Tutors</h3>
                    <p>Join our diverse community of tutors. Embrace varied expertise to meet students' unique needs.</p>
                </div>

                <div className="benefits--section">
                    <span className="material-symbols-outlined home-icon">admin_panel_settings</span>
                    <h3>Verified Profiles</h3>
                    <p>Find reliable educators, verified for your learning assurance.</p>
                </div>

                <div className="benefits--section">
                    <span className="material-symbols-outlined home-icon">local_library</span>
                    <h3>Pay Per Session</h3>
                    <p>Book sessions directly with your chosen tutor. Securely pay upfront for convenient scheduling and peace of mind.</p>
                </div>

                <div className="benefits--section">
                    <span className="material-symbols-outlined home-icon">payments</span>
                    <h3>Affordable Prices</h3>
                    <p>Explore our cost-effective pricing options. Access high-quality tutoring services at competitive rates.</p>
                </div>
            </div>
           
            <hr></hr>
        </div>
    )
}