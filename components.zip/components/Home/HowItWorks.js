import React from "react";
import "../../styles/styles.css";

export default function HowItWorks() {
    return (
        <div id="how-it-works--container">
            <div id="how-it-works--title">
                <h1>How it all works</h1>
                <hr className="small-hr"></hr>
            </div>

            <div id="how-it-works--all-info">
                <div id="how-it-works--img"></div>
                <div id="how-it-works--info">
                    <div className="how-it-works--list">
                        <h1 className="number-list">1</h1>
                        <div className="paragraph-list">
                            <h3>Find the perfect tutor</h3>
                            <p>Discover expert tutors tailored to your needs. Achieve academic success with personalized guidance.</p>
                        </div>
                    </div>

                    <div className="how-it-works--list">
                        <h1 className="number-list">2</h1>
                        <div className="paragraph-list">
                            <h3>Schedule your lesson</h3>
                            <p>Book convenient sessions at your preferred time and connect with top tutors instantly. Your academic success starts here.</p>
                        </div>
                    </div>

                    <div className="how-it-works--list">
                        <h1 className="number-list">3</h1>
                        <div className="paragraph-list">
                            <h3>Start the journey</h3>
                            <p>Embark on your academic journey today. Let's achieve your goals together.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}