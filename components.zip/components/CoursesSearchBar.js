import React from "react";
import "../styles/styles.css";
// import majorsList from "../data/majorsList";

export default function CoursesSearchBar(props) {
    const { major, majorId, courses, coursesFiltered, setCoursesFiltered, setCourses, setMajor, setMajorId, searchCourse, setSearchCourse } = props;
    const [majors, setMajors] = React.useState([]);
    const [majorsOptions, setMajorsOptions] = React.useState([]);

    // Get the majors from the database
    const fetchMajors = async () => {
        try {
            const res = await fetch('http://127.0.0.1:8000/majors');
            const data = await res.json();
            setMajors(data);
        } catch (error) {
            console.log(error);
        }
    }

    // Search for courses
    const searchCourses = async() => {
        try {
            let data = []
            if (searchCourse !== "") {
                const res = await fetch(`http://127.0.0.1:8000/searchCourses/${searchCourse}`);
                data = await res.json();
            }
            setCoursesFiltered(() => data.filter((course) => courses.some((fetchedCourse) => {
                return fetchedCourse.name === course.name;
            })));
        } catch (error) {
            console.log(error);
        }
    }

    React.useEffect(() => {
        fetchMajors();
    }, []);

    React.useEffect(() => {
        setMajorsOptions(() => {
            return majors.map((major, id) => <option value={`${major.id}-${major.name}`} key={id}>{major.name}</option>)
        })
    }, [majors]);


    // Handle the searching of the course
    function handleSearch(event) {
        setSearchCourse(event.target.value);
    }

    React.useEffect(() => {
        searchCourses();
    }, [searchCourse])

    // Handle the change of the major
    function handleChange(event) {
        const currVal = event.target.value;

        if (currVal === "") {
            setMajorId(-1);
            setMajor("");
        } else {
            setMajor(currVal.substring(currVal.search('-') + 1));
            setMajorId(currVal.substring(0,currVal.search('-')));
        }
    }

    return (
        <div className="search--container">
            <div id="search-bar">
                <input type="text" placeholder="Search Courses" onChange={handleSearch} value={searchCourse} />
                <span className="material-symbols-outlined" id="search-icon">search</span>
            </div>

            <select
                value={`${majorId}-${major}`}
                onChange={handleChange}
                className="select"
            >
                <option value="">All Majors</option>
                {majorsOptions}
            </select>
        </div>
    )
}