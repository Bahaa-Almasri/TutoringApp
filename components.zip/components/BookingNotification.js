import React from "react";
import daysMapping from "../data/daysMappings";
import axios from "axios";

export default function BookingNotification(props) {

    const addBooking = async () => {
        try {
            await axios.put(`http://127.0.0.1:8000/user/bookSlot`, {
                hour: props.id
            }, {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Token ${props.token}`
                }
            });
        } catch (error) {
            console.log(error);
        }
    }

    function handleConfirm(isConfirmed) {
        props.setBookingNotification(prev => ({
                ...prev,
                show: false
            })
        )

        if (isConfirmed) {
            // Update the database with the info needed
            addBooking();

            // Reload the booking page
            window.location.reload();
        }
    }

    return (
        <div id="booking-notification--container">
            <h3>You are booking a session with {props.tutor}.</h3>
            <div className="flex-row">
                <p className="booking-notification--subtitle">Course: </p>
                <p>{props.course}</p>
            </div>
            <div className="flex-row">
                <p className="booking-notification--subtitle">Date and time: </p>
                <p>{`${daysMapping[props.day]} at ${props.hour}:00`}</p>
            </div>
            <div className="flex-row">
                <p className="booking-notification--subtitle">Total: </p>
                <p>{`$ ${props.hourlyRate}`}</p>
            </div>

            <div id="booking-notif-buttons">
                <button className="small-button" onClick={() => handleConfirm(true)}>Confirm</button>
                <button className="small-button" id="red-button" onClick={() => handleConfirm(false)}>Cancel</button>
            </div>
        </div>
    )
}