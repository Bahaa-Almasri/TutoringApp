import React from "react";
import { Link } from "react-router-dom";
import "../styles/booking.css";
import { useLocation } from "react-router-dom"
import BookingNotification from "./BookingNotification";
import axios from "axios";

export default function Booking() {
    const startingHour = 7; 
    const booked = "booked";
    const available = "available";
    
    const { state } = useLocation();
    const token = state.token ? state.token : "";

    const [schedule, setSchedule] = React.useState([
        ["", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
        ["07:00","", "", "", "", "", "", ""],
        ["08:00","", "", "", "", "", "", ""],
        ["09:00","", "", "", "", "", "", ""],
        ["10:00","", "", "", "", "", "", ""],
        ["11:00","", "", "", "", "", "", ""],
        ["12:00","", "", "", "", "", "", ""],
        ["13:00","", "", "", "", "", "", ""],
        ["14:00","", "", "", "", "", "", ""],
        ["15:00","", "", "", "", "", "", ""],
        ["16:00","", "", "", "", "", "", ""],
        ["17:00","", "", "", "", "", "", ""],
        ["18:00","", "", "", "", "", "", ""],
        ["19:00","", "", "", "", "", "", ""],
        ["20:00","", "", "", "", "", "", ""],
        ["21:00","", "", "", "", "", "", ""],
        ["22:00","", "", "", "", "", "", ""]
    ]);
    const [availableHours, setAvailableHours] = React.useState([]);
    const [noHours, setNoHours] = React.useState(false);
    const [scheduleElement, setScheduleElement] = React.useState([[]]);

    // Get the tutor's available hours
    const fetchHours = async () => {
        try {
            const res = await axios.get(`http://127.0.0.1:8000/getTutorAvailableHours/${state.tutorId}`, {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Token ${token}`
                }
            });
            setAvailableHours(res.data);
        } catch (error) {
            console.log(error);
        }
    }

    React.useEffect(() => {
        fetchHours();
    }, [])


    // Set up the schedule array
    React.useEffect(() => {
        setSchedule((prevArr) => {
            const prev = [...prevArr];
            for (let i = 0; i < availableHours.length; i++) {
                let currCol = availableHours[i].day;
                let currRow = availableHours[i].hour - startingHour + 1;
                prev[currRow][currCol] = `${availableHours[i].id}-${availableHours[i].is_booked ? booked : available}`;
            }

            return prev;
        })
    }, [availableHours])

    // Set up the elements that will show for the schedule
    React.useEffect(() => {
        setScheduleElement(() => schedule.map((currArr, rowIdx) => {
            return (
                <div className="calendar-row">
                    {
                        currArr.map((currEdited, columnIdx) => {
                            const cellKey = `${rowIdx}-${columnIdx}`;
                            if (columnIdx === 0 && rowIdx === 0) return <div key={cellKey} id="first-cell"></div>

                            const curr = currEdited.substring(currEdited.search('-') + 1);
                            const currId = currEdited.substring(0, currEdited.search('-'));
                            const isDay = rowIdx === 0;
                            
                            if (curr === booked) return <div key={cellKey} className="booked-booking"></div>
                            else if (curr === available) return <div key={cellKey} className="available-booking" onClick={() => book(currId, rowIdx, columnIdx)} ></div>
                            else if (curr !== "") return <div key={cellKey} className={isDay ? "day-cell ": "hour-cell"}>{curr}</div>;
                            else return <div key={cellKey} className="unavailable-booking"></div>
                            }
                        )
                    }
                </div>
        )}))
    }, [schedule])

    // The user wants to book the clicked session
    const [bookingNotification, setBookingNotification] = React.useState({ show: false });
    function book(id, row, col) {
        const currHour = row + startingHour - 1;
        const currDay = col - 1;
        
        setBookingNotification(() => {
            return {
                show: true,
                id: Number(id),
                hour: currHour,
                day: currDay
            }
        })
    }
    
    return (
        <div id="booking-page">
            <div id="booking--title">
                <Link to="/tutors" className="back-button" state={{token: token}}>
                    <span className="material-symbols-outlined">arrow_back_ios</span>
                </Link>
                <div className="booking--full-title" >
                    <h1 className="h1-title">Book your session with {state.tutor}</h1>
                    <hr></hr>
                </div>
            </div>

            {noHours && <p className="not-found">No hours are currently available.</p>}
            {!noHours &&
                <div id="booking--container">
                    {scheduleElement}
                </div>
            }
            {bookingNotification.show && 
                <BookingNotification 
                    tutor={state.tutor}
                    day={bookingNotification.day}
                    hour={bookingNotification.hour}
                    id={bookingNotification.id}
                    course={state.course}
                    hourlyRate={state.hourlyRate}
                    setBookingNotification={setBookingNotification}
                    token={token}
                />
            }
        </div>
    )
}