import React from "react";
import "../styles/styles.css";
import PageIntro from "./PageIntro";
import Footer from "./Footer";
import SmallIntro from "./SmallIntro";
import { useLocation } from "react-router-dom"; 

export default function About() {
    const location = useLocation();
    const token = location.state ? location.state.token : "";

    return (
        <div className="flex-column">
            <PageIntro 
                active="about"
                title="About Us"
                description="We are a platform where students and tutors meet."
                background="background-image-about"
                token={token}
            />

            <div id="about--container">
                <SmallIntro 
                    smallTitle={"About us"}
                    title={"We connect students and tutors."}
                    description={"At BrainBite, we're dedicated to revolutionizing the way students find tutors and tutors connect with eager learners. Our platform is designed to bridge the gap between education seekers and knowledgeable mentors, providing a seamless and empowering experience for both parties."}
                />

                <div id="vision-mission--container">
                    <div>
                        <p className="small-title">Our Vision</p>
                        <p>We envision a world where every student has access to personalized, high-quality education tailored to their individual needs and aspirations. We believe that learning should be a lifelong journey fueled by curiosity, passion, and mentorship.</p>
                    </div>
                    
                    <div>
                        <p className="small-title">Our Mission</p>
                        <p>Our mission is simple yet profound: to empower students to achieve their academic goals and to enable tutors to share their expertise with the world. We believe that education is the cornerstone of success, and by facilitating meaningful connections between tutors and students, we're contributing to a brighter future for all.</p>
                    </div>
                </div>

                <div id="about-image"></div>

                <div id="why-us--container">
                    <div>
                        <p className="small-title"> Why us</p>
                        <h3 className="h3-title">Ace your courses.</h3>
                    </div>

                    <div>
                        <div className="why-us--text">
                            <span className="material-symbols-outlined down-arrow">arrow_insert</span>
                            <div>
                                <h6 className="why-us-subtitle">Expert help</h6>
                                <p className="light-grey">Whether you're looking for help understanding complex concepts, preparing for exams, or navigating career decisions, our tutors can help.</p>
                            </div>
                        </div>
                        
                        <div className="why-us--text">
                            <span className="material-symbols-outlined down-arrow">arrow_insert</span>
                            <div>
                                <h6 className="why-us-subtitle">Pay per session</h6>
                                <p className="light-grey">With our pay-per-session model, you have the freedom to schedule tutoring sessions according to your own timetable and budget.</p>
                            </div>
                        </div>
                    </div>

                    <div>
                        <p className="small-title">Why us</p>
                        <h3 className="h3-title">Launch your tutoring career.</h3>
                    </div>

                    <div>
                        <div className="why-us--text">
                            <span className="material-symbols-outlined down-arrow">arrow_insert</span>
                            <div>
                                <h6 className="why-us-subtitle">Reach a wide audience</h6>
                                <p className="light-grey">Reach a wide audience of students in need of a tutor by listing your profile on our website. Establish yourself as a brilliant tutor for students actively seeking academic support.</p>
                            </div>
                        </div>
                        
                        <div className="why-us--text">
                            <span className="material-symbols-outlined down-arrow">arrow_insert</span>
                            <div>
                                <h6 className="why-us-subtitle">Pay per month</h6>
                                <p className="light-grey">With our pay-per-month model, your profile will be featured on our website for the courses of your choosing, without any commission deducted from your sessions.</p>
                                
                            </div>
                        </div>
                    </div>

                </div>
            </div>

            <Footer token={token} />
        </div>
    )
}