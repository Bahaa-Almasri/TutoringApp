import React from "react";
import "../styles/styles.css";

export default function TutorsSearchBar(props) {
    const { formData, setFormData, tutorsFiltered, setTutorsFiltered, tutors, setTutors } = props;

    const [searchTutor, setSearchTutor] = React.useState([]);

    const [courses, setCourses] = React.useState([]);
    const [languages, setLanguages] = React.useState([]);

    const [currentChange, setCurrentChange] = React.useState("");
    
    const [searchResult, setSearchResult] = React.useState([]);
    const [coursesFiltered, setCoursesFiltered] = React.useState([]);
    const [languagesFiltered, setLanguagesFiltered] = React.useState([]);
    const [rateFiltered, setRateFiltered] = React.useState([]);
    
    const [coursesOptions, setCoursesOptions] = React.useState([]);
    const [ratingsOptions, setRatingsOptions] = React.useState([]);
    const [languageOptions, setLanguageOptions] = React.useState([]);
    const [rateOptions, setRateOptions] = React.useState([]);

    // Check if an object course is found
    function checkObjectCourse(arr, obj, course) {
        let courseEdited = course.substring(course.search('-') + 1);
        for (let i = 0; i < arr.length; i++) {
            if (obj.first_name === arr[i].first_name && obj.last_name === arr[i].last_name && courseEdited === obj.course) {
                return true;
            }
        }
        return false;
    }

    // Check if an object language is found
    function checkObjectLanguage(arr, obj, language) {
        let languageEdited = language.substring(0, language.search('-'));
        for (let i = 0; i < arr.length; i++) {
            if (obj.first_name === arr[i].first_name && obj.last_name === arr[i].last_name && obj.languages.includes(Number(languageEdited))) {
                return true;
            }
        }
        return false;
    }

    // Check if an object rate is found
    function checkObjectRate(arr, obj, course) {
        for (let i = 0; i < arr.length; i++) {
            if (obj.first_name === arr[i].first_name && obj.last_name === arr[i].last_name && arr[i].rate === obj.rate) {
                return true;
            }
        }
        return false;
    }

    // Get the intersection between the courses array and the filtering array
    const fetchFilteredCourses = async (courseId) => {
        try {
            const res = await fetch(`http://127.0.0.1:8000/getCourseTutors/${courseId}`);
            const data = await res.json();
            setCoursesFiltered(data);
        } catch(error) {
            console.log(error);
        }
    }

    // Get the intersection between the languages array and the filtering array
    const fetchFilteredLanguages = async (languageId) => {
        try {
            const res = await fetch(`http://127.0.0.1:8000/getLanguageTutors/${languageId}`);
            const data = await res.json();
            setLanguagesFiltered(data);
        } catch(error) {
            console.log(error);
        }
    }

    // Get the intersection between the rate array and the filtering array
    const fetchFilteredRate = async (rate) => {
        try {
            const res = await fetch(`http://127.0.0.1:8000/getRateTutors/${rate}`);
            const data = await res.json();
            setRateFiltered(data);
        } catch(error) {
            console.log(error);
        }
    }

    // Change the array when the form is changed
    React.useEffect(() => {
        let courseId = formData[currentChange] ? formData[currentChange] : "";
        courseId = courseId.substring(0, courseId.search('-'));
        
        let languageId = formData[currentChange] ? formData[currentChange] : "";
        languageId = languageId.substring(0, languageId.search('-'));

        if (currentChange === "course") {
            if (formData.course === "") {
                setTutorsFiltered(tutors);
            }

            fetchFilteredCourses(courseId);
        } else if (currentChange === "language") {
            if (formData.language === "") {
                setTutorsFiltered(tutors);
            }

            fetchFilteredLanguages(languageId);
        } 
        else if (currentChange === "hourlyRate") {
            if (formData.hourlyRate === "") {
                setTutorsFiltered(tutors);
            }

            fetchFilteredRate(formData.hourlyRate);
        }
    }, [formData, currentChange])

    React.useEffect(() => {
        setTutorsFiltered(() => tutors.filter(tutor => checkObjectCourse(coursesFiltered, tutor, formData.course)));
    }, [coursesFiltered])

    React.useEffect(() => {
        setTutorsFiltered(() => tutors.filter(tutor => checkObjectLanguage(languagesFiltered, tutor, formData.language)));
    }, [languagesFiltered])

    React.useEffect(() => {
        setTutorsFiltered(() => tutors.filter(tutor => checkObjectRate(rateFiltered, tutor, formData.hourlyRate)));
    }, [rateFiltered])

    // Get the courses from the database
    const fetchCourses = async () => {
        try {
            let res;
            res = await fetch('http://127.0.0.1:8000/courses');
            const data = await res.json();
            setCourses(data);
        } catch (error) {
            console.log(error);
        }
    }

    // Search for tutors
    const searchTutors = async() => {
        try {
            let data = []
                const res = await fetch(`http://127.0.0.1:8000/searchTutors/${searchTutor}`);
                data = await res.json();
                setSearchResult(data);
        } catch (error) {
            console.log(error);
        }
    }

    // Get the languages from the database
    const fetchLanguages = async () => {
        try {
            let res;
            res = await fetch('http://127.0.0.1:8000/listLanguages');
            const data = await res.json();
            setLanguages(data);
        } catch (error) {
            console.log(error);
        }
    }

    function handleChange(event) {
        setFormData(prevData => {
            return {
                ...prevData,
                [event.target.name]: event.target.value
            }
        })

        setCurrentChange(event.target.name);
    }

    function handleSearch(event) {
        setSearchTutor(event.target.value);
    }

    React.useEffect(() => {
        searchTutors();
    }, [searchTutor])

    // Set the options
    React.useEffect(() => {
        setCoursesOptions(() => {
            return courses.map((course, id) => {
                return <option key={id} value={`${course.id}-${course.name}`} >{course.name}</option>
            })
        })

        setRatingsOptions(() => {
            return [<option key={5} value="5">5 Only</option>,
                    <option key={4} value="4">4 and Above</option>,
                    <option key={3} value="3">3 and Above</option>,
                    <option key={2} value="2">2 and Above</option>,
                    <option key={1} value="1">1 and Above</option>];
        }) 

        setLanguageOptions(() => {
            return languages.map((language, id) => <option key={id} value={`${language.id}-${language.name}`}>{language.name}</option>);
        })

        setRateOptions(() => {
            return [<option key={5} value="25">25 and Below</option>,
                    <option key={4} value="20">20 and Below</option>,
                    <option key={3} value="15">15 and Below</option>,
                    <option key={2} value="10">10 and Below</option>,
                    <option key={5} value="5">5 and Below</option>];
        })
    }, [languages, courses, props]);

    // Fetch languages and courses
    React.useEffect(() => {
        fetchLanguages();
        fetchCourses();
    }, [])

    return (
        <div className="search--container" id="tutors-search--container">
            <div id="search-bar">
                <input type="text" placeholder="Search Tutor" onChange={handleSearch} value={searchTutor} />
                <span className="material-symbols-outlined" id="search-icon">search</span>
            </div>

            <form id="tutors-selects--container">
                <select
                    value={formData.course}
                    onChange={handleChange}
                    className="select"
                    id="select-tutor"
                    name="course"
                >
                    <option value="">All Courses</option>
                    {coursesOptions}
                </select>

                <select
                    value={formData.rating}
                    onChange={handleChange}
                    className="select"
                    id="select-tutor"
                    name="rating"
                >
                    <option value="all">All Ratings</option>
                    {ratingsOptions}
                </select>

                <select
                    value={formData.language}
                    onChange={handleChange}
                    className="select"
                    id="select-tutor"
                    name="language"
                >
                    <option value="">All Languages</option>
                    {languageOptions}
                </select>

                <select
                    value={formData.hourlyRate}
                    onChange={handleChange}
                    className="select"
                    id="select-tutor"
                    name="hourlyRate"
                >
                    <option value="">All Hourly Rates</option>
                    {rateOptions}
                </select>
            </form>
        </div>
    )
}