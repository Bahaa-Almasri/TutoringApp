import React from "react";
import "../styles/styles.css";
import { Link } from "react-router-dom";

export default function TutorBox(props) {
    const halfStar = "half", fullStar = "full", emptyStar = "empty";

    const [languages, setLanguages] = React.useState("");
    const [stars, setStars] = React.useState([]);
    const [starsDisplay, setStarsDisplay] = React.useState([]);

    React.useEffect(() => {
        setLanguages(() => props.languages.reduce((languagesString, currLanguage) => languagesString += ", " + currLanguage));

        // Depending on how the API will go, you can think of moving it outside or not
        let { rating } = props;
        rating = Number(rating);
        let starsArr = [emptyStar, emptyStar, emptyStar, emptyStar, emptyStar];

        for (let i = 0; i < 5 && rating > 0; i++) {
            if (rating < 1) {
                starsArr[i] = halfStar;
            } else {
                starsArr[i] = fullStar;
            }

            rating -= 1;
        }

        setStars(starsArr); // specified which stars are filled which are not
    }, [props]);


    // Creates the review stars for each tutor
    React.useEffect(() => {
        setStarsDisplay(() => {
            return stars.map((starState, key) => {
                const starName = starState === halfStar ? "star_half" : "star";
                let starClass = "material-symbols-outlined";
                starClass += starState === fullStar ? " filled-star" : "";

                return <span key={key} className={starClass}>{starName}</span>;
            })
        })
    }, [stars]);
  
    return (
        <div className="tutor-box--container">
            <div className="tutor-box--course">
                <p className="green-p-box medium-size">{props.code}</p>
                <div className="course-title">
                    <p>{props.course}</p>
                </div>
                
                 {/* <div className="tutor-box--profile">
                    <span class="material-symbols-outlined">account_circle</span>
                </div> */}
                <div id="tutor-rating--container">
                    <p>{props.rating}</p>
                    <div>
                        {starsDisplay}
                    </div>
                </div>
                <Link 
                    className="small-button" 
                    to="/tutors/booking" 
                    state={{ 
                        tutor: props.tutor,
                        course: props.course,
                        hourlyRate: props.hourlyRate,
                        tutorId: props.id,
                        token: props.token
                    }}
                    >Book Session</Link>
            </div>

            <div className="tutor-box--tutor">
                <h3 className="light-title larger-size">{props.tutor}</h3>
                <p className="light-grey regular">{props.description}</p>

                <div id="language--container">
                    <p className="very-small-title">SPEAKS:</p>
                    <p className="light-grey regular">{languages}</p>
                </div>

                <div id="hourly-rate--container">
                    <p className="very-small-title">HOURLY RATE FROM:</p>
                    <div className="flex-row light-grey">
                        <p className="regular">USD&nbsp;</p>
                        <p className="bold">{props.hourlyRate}</p>
                    </div>
                </div>
            </div>
        </div>
    )
}